import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { ProgressProvider } from "./context/ProgressContext";
import Home from "./pages/Home";
import DayView from "./pages/DayView";
import TimeTracking from "./pages/TimeTracking";
import YearOverview from "./pages/YearOverview";

export default function App() {
  return (
    <ProgressProvider>
      <Router>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/tag/:day" element={<DayView />} />
          <Route path="/zeiterfassung" element={<TimeTracking />} />
          <Route path="/jahresuebersicht" element={<YearOverview />} />
        </Routes>
      </Router>
    </ProgressProvider>
  );
}

