export interface TaskItem {
  text: string;
  count?: number; // Anzahl der Unterpunkte
  isBooster?: boolean; // Booster-Aufgabe für über 100%
}

export interface TaskSection {
  title: string;
  color: string;
  backgroundColor: string;
  borderColor: string;
  isHeader?: boolean; // Nur Überschrift, nicht abhakbar
  tasks: TaskItem[];
}

export interface WeekGoals {
  customerContacts: number;
  offers: number;
  personalFocus: string;
}

export const dayTasks: Record<string, TaskSection[]> = {
  Mo: [
    {
      title: "📋 Tägliche Aufgaben",
      color: "#1e40af",
      backgroundColor: "#dbeafe",
      borderColor: "#3b82f6",
      tasks: [
        { text: "📌 CRM aktualisieren" },
        { text: "🔍 Architekturbüros recherchieren", count: 5 },
        { text: "🏗️ Projekte finden", count: 2 },
      ]
    },
    {
      title: "LinkedIn PersonalBrand",
      color: "#0a66c2",
      backgroundColor: "#e0f2fe",
      borderColor: "#0284c7",
      isHeader: true,
      tasks: [
        { text: "💡 Beitrag für LinkedIn brainstormen" },
        { text: "👍 Relevante Beiträge liken und kommentieren", count: 3 },
        { text: "🔍 Neue Kontakte prüfen (z.B. Architekten)" },
        { text: "💬 Eine Direktnachricht an potenziellen Kontakt senden" },
      ]
    },
    {
      title: "🚀 Booster-Aufgabe",
      color: "#7c3aed",
      backgroundColor: "#f3e8ff",
      borderColor: "#8b5cf6",
      tasks: [
        { text: "🎯 Extra Kundentermin vereinbaren", isBooster: true },
      ]
    }
  ],
  Di: [
    {
      title: "📋 Tägliche Aufgaben",
      color: "#1e40af",
      backgroundColor: "#dbeafe",
      borderColor: "#3b82f6",
      tasks: [
        { text: "📌 CRM aktualisieren" },
        { text: "📞 Kaltakquise-Anrufe", count: 3 },
        { text: "📧 Akquise-Mails schreiben", count: 3 },
        { text: "👤 Kontakte nachfassen" },
      ]
    },
    {
      title: "LinkedIn PersonalBrand",
      color: "#0a66c2",
      backgroundColor: "#e0f2fe",
      borderColor: "#0284c7",
      isHeader: true,
      tasks: [
        { text: "📱 Eigenen Beitrag posten (z.B. Projektidee oder Foto)" },
        { text: "🎯 Zwei Kontakte auf den Beitrag ansprechen" },
        { text: "✏️ LinkedIn-Profil aktualisieren (z.B. Skills oder Slogan)" },
      ]
    },
    {
      title: "🚀 Booster-Aufgabe",
      color: "#7c3aed",
      backgroundColor: "#f3e8ff",
      borderColor: "#8b5cf6",
      tasks: [
        { text: "💼 Zusätzliches Angebot erstellen", isBooster: true },
      ]
    }
  ],
  Mi: [
    {
      title: "📋 Tägliche Aufgaben",
      color: "#1e40af",
      backgroundColor: "#dbeafe",
      borderColor: "#3b82f6",
      tasks: [
        { text: "📌 CRM aktualisieren" },
        { text: "🔍 Key Account Check – Potenziale identifizieren", count: 3 },
        { text: "👥 Entscheider und neue Kontakte finden", count: 3 },
        { text: "📋 Vorbereitung für persönliches Follow-up", count: 3 },
      ]
    },
    {
      title: "LinkedIn PersonalBrand",
      color: "#0a66c2",
      backgroundColor: "#e0f2fe",
      borderColor: "#0284c7",
      isHeader: true,
      tasks: [
        { text: "📊 Einen Beitrag analysieren (was funktioniert bei anderen)" },
        { text: "💬 Kommentar mit echtem Mehrwert schreiben" },
        { text: "🔄 Expertenbeitrag aus der Branche teilen" },
      ]
    },
    {
      title: "🚀 Booster-Aufgabe",
      color: "#7c3aed",
      backgroundColor: "#f3e8ff",
      borderColor: "#8b5cf6",
      tasks: [
        { text: "🎪 Branchenevent oder Webinar besuchen", isBooster: true },
      ]
    }
  ],
  Do: [
    {
      title: "📋 Tägliche Aufgaben",
      color: "#1e40af",
      backgroundColor: "#dbeafe",
      borderColor: "#3b82f6",
      tasks: [
        { text: "📌 CRM aktualisieren" },
        { text: "🤝 Netzwerkgespräch führen" },
        { text: "📚 Bau-Impuls lesen & notieren" },
      ]
    },
    {
      title: "LinkedIn PersonalBrand",
      color: "#0a66c2",
      backgroundColor: "#e0f2fe",
      borderColor: "#0284c7",
      isHeader: true,
      tasks: [
        { text: "💌 LinkedIn-Nachricht an Wunschkunden senden" },
        { text: "💭 Feedback oder Austausch zu einem Projekt posten" },
        { text: "👀 Drei neue Profile aus der Zielgruppe anschauen" },
      ]
    },
    {
      title: "🚀 Booster-Aufgabe",
      color: "#7c3aed",
      backgroundColor: "#f3e8ff",
      borderColor: "#8b5cf6",
      tasks: [
        { text: "📈 Marktanalyse für neues Segment", isBooster: true },
      ]
    }
  ],
  Fr: [
    {
      title: "📋 Tägliche Aufgaben",
      color: "#1e40af",
      backgroundColor: "#dbeafe",
      borderColor: "#3b82f6",
      tasks: [
        { text: "📌 CRM aktualisieren" },
        { text: "♻️ Ruhende Projekte reaktivieren", count: 3 },
        { text: "🔍 Verlorene Projekte analysieren", count: 2 },
        { text: "🗓️ Nächste Woche planen" },
      ]
    },
    {
      title: "LinkedIn PersonalBrand",
      color: "#0a66c2",
      backgroundColor: "#e0f2fe",
      borderColor: "#0284c7",
      isHeader: true,
      tasks: [
        { text: "📝 Wochenrückblick vorbereiten und posten" },
        { text: "⭐ Zwei neue Empfehlungen schreiben oder anfragen" },
        { text: "🏷️ Netzwerkkontakte sortieren und taggen" },
      ]
    },
    {
      title: "🚀 Booster-Aufgabe",
      color: "#7c3aed",
      backgroundColor: "#f3e8ff",
      borderColor: "#8b5cf6",
      tasks: [
        { text: "🎉 Erfolgreiche Woche mit Team feiern", isBooster: true },
      ]
    }
  ],
  Sa: [
    {
      title: "✨ Freiwillige Aktivitäten",
      color: "#059669",
      backgroundColor: "#d1fae5",
      borderColor: "#10b981",
      tasks: [
        { text: "✨ Freiwillige Booster-Aufgabe" }
      ]
    }
  ],
  So: [
    {
      title: "💭 Kreative Zeit",
      color: "#059669",
      backgroundColor: "#d1fae5",
      borderColor: "#10b981",
      tasks: [
        { text: "💭 Planung oder Kreativideen notieren" }
      ]
    }
  ],
};