import React, { createContext, useContext, useState, useEffect, type ReactNode } from 'react';

export interface TaskProgress {
  [day: string]: boolean[];
}

export interface ProgressContextType {
  taskProgress: TaskProgress;
  updateTaskProgress: (day: string, taskIndex: number, completed: boolean) => void;
  getDayProgress: (day: string, totalTasks: number) => number;
  isDayComplete: (day: string, totalTasks: number) => boolean;
}

const ProgressContext = createContext<ProgressContextType | undefined>(undefined);

export const useProgress = () => {
  const context = useContext(ProgressContext);
  if (!context) {
    throw new Error('useProgress must be used within a ProgressProvider');
  }
  return context;
};

interface ProgressProviderProps {
  children: ReactNode;
}

export const ProgressProvider: React.FC<ProgressProviderProps> = ({ children }) => {
  const [taskProgress, setTaskProgress] = useState<TaskProgress>({});

  // localStorage laden beim Start
  useEffect(() => {
    const savedProgress = localStorage.getItem('vertriebswoche-progress');
    if (savedProgress) {
      try {
        setTaskProgress(JSON.parse(savedProgress));
      } catch (error) {
        console.error('Fehler beim Laden des Fortschritts:', error);
      }
    }
  }, []);

  // localStorage speichern bei Änderungen
  useEffect(() => {
    localStorage.setItem('vertriebswoche-progress', JSON.stringify(taskProgress));
  }, [taskProgress]);

  const updateTaskProgress = (day: string, taskIndex: number, completed: boolean) => {
    setTaskProgress(prev => {
      const dayTasks = prev[day] || [];
      const newDayTasks = [...dayTasks];
      newDayTasks[taskIndex] = completed;
      
      return {
        ...prev,
        [day]: newDayTasks
      };
    });
  };

  const getDayProgress = (day: string, totalTasks: number): number => {
    const dayTasks = taskProgress[day] || [];
    const completedTasks = dayTasks.filter(Boolean).length;
    return totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
  };

  const isDayComplete = (day: string, totalTasks: number): boolean => {
    return getDayProgress(day, totalTasks) === 100;
  };

  return (
    <ProgressContext.Provider value={{
      taskProgress,
      updateTaskProgress,
      getDayProgress,
      isDayComplete
    }}>
      {children}
    </ProgressContext.Provider>
  );
};