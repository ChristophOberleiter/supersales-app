import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { dayTasks } from "../data/tasks";
import { calculateTimeStats, formatHours } from "../utils/timeUtils";
import type { TimeEntry } from "../types/timeTracking";

interface TaskProgress {
  [day: string]: boolean[];
}

const weekdays = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"];
const motivationalQuotes = [
  "Ziele sind Gedanken mit Richtung",
  "Wer sich bewegt, formt die Welt – und sich selbst",
  "Setz dir Ziele, die dich morgens aufstehen lassen",
  "Dein Kalender ist dein Kompass – wohin zeigt deiner heute?",
  "Woche starten. Fokus setzen. Wirkung erzeugen",
  "Jede Aufgabe bringt dich näher – mach sie sichtbar!",
  "To-dos sind wie Gemüse – besser, wenn man sie früh isst",
  "Ziele machen aus Montag keinen Freitag – aber fast",
  "Wer schreibt, der bleibt – und gewinnt!",
  "Vision trifft Aktion – das ist deine Woche",
  "Erfolg ist die Summe kleiner Anstrengungen, die Tag für Tag wiederholt werden",
  "Jeder Kontakt ist eine Chance. Jede Chance ist ein Schritt zum Erfolg",
  "Heute ist der perfekte Tag, um außergewöhnliche Ergebnisse zu erzielen",
  "Deine Beständigkeit heute bestimmt deinen Erfolg morgen",
  "Vertrieb ist nicht nur ein Job – es ist die Kunst, Träume zu verwirklichen"
];

export default function Home() {
  const navigate = useNavigate();
  const [currentGoalHeadline, setCurrentGoalHeadline] = useState("");
  const [taskProgress, setTaskProgress] = useState<TaskProgress>({});
  const [weeklyGoals, setWeeklyGoals] = useState(() => {
    const saved = localStorage.getItem("weekly-goals");
    return saved ? JSON.parse(saved) : ["", "", ""];
  });
  const [editGoalIndex, setEditGoalIndex] = useState<number | null>(null);

  const hasLinkedInTasksOld = (day: string): boolean => {
    const savedProgress = localStorage.getItem(`progress_${day}`);
    if (!savedProgress) return false;
    
    try {
      const dayProgress = JSON.parse(savedProgress);
      let taskIndex = 0;
      
      const taskSections = dayTasks[day] || [];
      for (const section of taskSections) {
        // Prüfe nur LinkedIn PersonalBrand Sections (die sind Header)
        if (section.title === "LinkedIn PersonalBrand" && section.isHeader) {
          for (const task of section.tasks) {
            const subtaskCount = task.count || 1;
            const taskChecks = dayProgress[taskIndex] || [];
            
            // Prüfe ob alle Subtasks dieser LinkedIn-Aufgabe erfüllt sind
            let allSubtasksComplete = true;
            for (let i = 0; i < subtaskCount; i++) {
              if (!taskChecks[i]) {
                allSubtasksComplete = false;
                break;
              }
            }
            
            // Wenn mindestens eine LinkedIn-Aufgabe komplett erfüllt ist
            if (allSubtasksComplete) {
              return true;
            }
            taskIndex++;
          }
        } else {
          // Überspringe andere Sections, aber zähle taskIndex weiter (nur bei nicht-Header)
          if (!section.isHeader) {
            section.tasks.forEach(() => {
              taskIndex++;
            });
          }
        }
      }
      
      return false;
    } catch (error) {
      console.error(`Fehler beim Prüfen der LinkedIn-Aufgaben für ${day}:`, error);
      return false;
    }
  };

  const hasLinkedInTasks = (day: string): boolean => {
    const savedProgress = localStorage.getItem(`progress_${day}`);
    if (!savedProgress) return false;
    
    try {
      const dayProgress = JSON.parse(savedProgress);
      let taskIndex = 0;
      
      const taskSections = dayTasks[day] || [];
      for (const section of taskSections) {
        if (section.title === "LinkedIn PersonalBrand") {
          for (const task of section.tasks) {
            const subtaskCount = task.count || 1;
            const taskChecks = dayProgress[taskIndex] || [];
            
            // Prüfe ob alle Subtasks dieser LinkedIn-Aufgabe erfüllt sind
            let allSubtasksComplete = true;
            for (let i = 0; i < subtaskCount; i++) {
              if (!taskChecks[i]) {
                allSubtasksComplete = false;
                break;
              }
            }
            
            // Wenn mindestens eine LinkedIn-Aufgabe komplett erfüllt ist
            if (allSubtasksComplete) {
              return true;
            }
            taskIndex++;
          }
        } else {
          // Andere Sections: taskIndex weiter zählen
          section.tasks.forEach(() => {
            taskIndex++;
          });
        }
      }
      
      return false;
    } catch (error) {
      console.error(`Fehler beim Prüfen der LinkedIn-Aufgaben für ${day}:`, error);
      return false;
    }
  };

  useEffect(() => {
    // Wechselnde Überschrift alle 2 Stunden (0-1, 2-3, 4-5, etc.)
    const currentHour = new Date().getHours();
    const headlineIndex = Math.floor(currentHour / 2) % motivationalQuotes.length;
    setCurrentGoalHeadline(motivationalQuotes[headlineIndex]);
    
    // Task Progress laden
    const savedProgress = localStorage.getItem('vertriebswoche-progress');
    if (savedProgress) {
      try {
        setTaskProgress(JSON.parse(savedProgress));
      } catch (error) {
        console.error('Fehler beim Laden des Fortschritts:', error);
      }
    }
  }, []);

  const hasBoosterTasks = (day: string): boolean => {
    const savedProgress = localStorage.getItem(`progress_${day}`);
    if (!savedProgress) return false;
    
    try {
      const dayProgress = JSON.parse(savedProgress);
      let taskIndex = 0;
      
      const taskSections = dayTasks[day] || [];
      for (const section of taskSections) {
        for (const task of section.tasks) {
          if (task.isBooster) {
            const subtaskCount = task.count || 1;
            const taskChecks = dayProgress[taskIndex] || [];
            for (let i = 0; i < subtaskCount; i++) {
              if (taskChecks[i]) {
                return true;
              }
            }
          }
          taskIndex++;
        }
      }
      
      return false;
    } catch (error) {
      console.error(`Fehler beim Prüfen der Booster-Aufgaben für ${day}:`, error);
      return false;
    }
  };

  const hasDailyTasks = (day: string): boolean => {
    const savedProgress = localStorage.getItem(`progress_${day}`);
    if (!savedProgress) return false;
    
    try {
      const dayProgress = JSON.parse(savedProgress);
      let taskIndex = 0;
      
      const taskSections = dayTasks[day] || [];
      for (const section of taskSections) {
        if (section.title === "📋 Tägliche Aufgaben") {
          for (const task of section.tasks) {
            const subtaskCount = task.count || 1;
            const taskChecks = dayProgress[taskIndex] || [];
            
            // Prüfe ob alle Subtasks dieser täglichen Aufgabe erfüllt sind
            let allSubtasksComplete = true;
            for (let i = 0; i < subtaskCount; i++) {
              if (!taskChecks[i]) {
                allSubtasksComplete = false;
                break;
              }
            }
            
            // Wenn nicht alle Subtasks erfüllt sind, ist die Section nicht komplett
            if (!allSubtasksComplete) {
              return false;
            }
            taskIndex++;
          }
          // Alle Aufgaben in "Tägliche Aufgaben" sind erfüllt
          return true;
        } else {
          // Andere Sections: taskIndex weiter zählen
          section.tasks.forEach(() => {
            taskIndex++;
          });
        }
      }
      
      return false;
    } catch (error) {
      console.error(`Fehler beim Prüfen der täglichen Aufgaben für ${day}:`, error);
      return false;
    }
  };

  const getDayProgress = (day: string, totalTasks: number): number => {
    const savedProgress = localStorage.getItem(`progress_${day}`);
    if (!savedProgress) return 0;
    
    try {
      const dayProgress = JSON.parse(savedProgress);
      let completedSubtasks = 0;
      let totalSubtasks = 0;
      let taskIndex = 0;
      
      const taskSections = dayTasks[day] || [];
      taskSections.forEach((section) => {
        section.tasks.forEach((task) => {
          // Booster-Aufgaben werden nicht für den Basis-Fortschritt gezählt
          if (!task.isBooster) {
            const subtaskCount = task.count || 1;
            totalSubtasks += subtaskCount;
            
            const taskChecks = dayProgress[taskIndex] || [];
            for (let i = 0; i < subtaskCount; i++) {
              if (taskChecks[i]) {
                completedSubtasks++;
              }
            }
          }
          taskIndex++;
        });
      });
      
      return totalSubtasks > 0 ? Math.round((completedSubtasks / totalSubtasks) * 100) : 0;
    } catch (error) {
      console.error(`Fehler beim Berechnen des Fortschritts für ${day}:`, error);
      return 0;
    }
  };

  const isDayComplete = (day: string, totalTasks: number): boolean => {
    return getDayProgress(day, totalTasks) === 100;
  };

  const handleGoalChange = (index: number, value: string) => {
    const updated = [...weeklyGoals];
    updated[index] = value;
    setWeeklyGoals(updated);
    localStorage.setItem("weekly-goals", JSON.stringify(updated));
  };

  const handleGoalSubmit = (index: number, value: string) => {
    handleGoalChange(index, value);
    setEditGoalIndex(null);
  };

  const getTimeStats = () => {
    const savedEntries = localStorage.getItem("time-entries");
    if (!savedEntries) return { weekHours: 0, monthHours: 0, yearHours: 0 };
    try {
      const entries: TimeEntry[] = JSON.parse(savedEntries);
      return calculateTimeStats(entries);
    } catch (error) {
      console.error("Fehler beim Laden der Zeiteinträge:", error);
      return { weekHours: 0, monthHours: 0, yearHours: 0 };
    }
  };

  const timeStats = getTimeStats();
  
  // Berechne alle erledigten Aufgaben (außer Booster) für 100%
  const completedAllTasks = weekdays.reduce((sum, day) => {
    const savedProgress = localStorage.getItem(`progress_${day}`);
    if (!savedProgress) return sum;
    
    try {
      const dayProgress = JSON.parse(savedProgress);
      let completedSubtasks = 0;
      let taskIndex = 0;
      
      const taskSections = dayTasks[day] || [];
      taskSections.forEach((section) => {
        section.tasks.forEach((task) => {
          if (!task.isBooster) {
            const subtaskCount = task.count || 1;
            const taskChecks = dayProgress[taskIndex] || [];
            for (let i = 0; i < subtaskCount; i++) {
              if (taskChecks[i]) {
                completedSubtasks++;
              }
            }
          }
          taskIndex++;
        });
      });
      
      return sum + completedSubtasks;
    } catch (error) {
      console.error(`Fehler beim Berechnen der Aufgaben für ${day}:`, error);
      return sum;
    }
  }, 0);
  
  // Berechne erfüllte Booster-Aufgaben (als Fleißbienchen)
  const completedBoosterTasks = weekdays.reduce((sum, day) => {
    const savedProgress = localStorage.getItem(`progress_${day}`);
    if (!savedProgress) return sum;
    
    try {
      const dayProgress = JSON.parse(savedProgress);
      let completedBoosters = 0;
      let taskIndex = 0;
      
      const taskSections = dayTasks[day] || [];
      taskSections.forEach((section) => {
        section.tasks.forEach((task) => {
          // Für Wochenende: alle Aufgaben zählen als Booster/Fleißbienchen
          // Für Werktage: nur explizite Booster-Aufgaben
          const isWeekend = day === "Sa" || day === "So";
          if (task.isBooster || isWeekend) {
            const subtaskCount = task.count || 1;
            const taskChecks = dayProgress[taskIndex] || [];
            for (let i = 0; i < subtaskCount; i++) {
              if (taskChecks[i]) {
                completedBoosters++;
              }
            }
          }
          taskIndex++;
        });
      });
      
      return sum + completedBoosters;
    } catch (error) {
      console.error(`Fehler beim Berechnen der Booster-Aufgaben für ${day}:`, error);
      return sum;
    }
  }, 0);
  
  // Berechne Gesamtanzahl aller Unteraufgaben (außer Booster)
  const totalAllTasks = weekdays.reduce((sum, day) => {
    const taskSections = dayTasks[day] || [];
    let dayTotalTasks = 0;
    
    taskSections.forEach(section => {
      section.tasks.forEach(task => {
        if (!task.isBooster) {
          dayTotalTasks += task.count || 1;
        }
      });
    });
    
    return sum + dayTotalTasks;
  }, 0);
  
  const weeklyProgress = totalAllTasks > 0 ? Math.round((completedAllTasks / totalAllTasks) * 100) : 0;

  // Berechne LinkedIn PersonalBrand Aufgaben als Prozent
  const completedLinkedInTasks = weekdays.reduce((sum, day) => {
    const savedProgress = localStorage.getItem(`progress_${day}`);
    if (!savedProgress) return sum;
    
    try {
      const dayProgress = JSON.parse(savedProgress);
      let completedLinkedIn = 0;
      let taskIndex = 0;
      
      const taskSections = dayTasks[day] || [];
      taskSections.forEach((section) => {
        if (section.title === "LinkedIn PersonalBrand" || section.title === "LI Pers.Brand") {
          section.tasks.forEach((task) => {
            const subtaskCount = task.count || 1;
            const taskChecks = dayProgress[taskIndex] || [];
            for (let i = 0; i < subtaskCount; i++) {
              if (taskChecks[i]) {
                completedLinkedIn++;
              }
            }
            taskIndex++;
          });
        } else {
          section.tasks.forEach(() => {
            taskIndex++;
          });
        }
      });
      
      return sum + completedLinkedIn;
    } catch (error) {
      console.error(`Fehler beim Berechnen der LinkedIn-Aufgaben für ${day}:`, error);
      return sum;
    }
  }, 0);

  // Berechne Gesamtanzahl LinkedIn PersonalBrand Aufgaben
  const totalLinkedInTasks = weekdays.reduce((sum, day) => {
    const taskSections = dayTasks[day] || [];
    let dayTotalLinkedIn = 0;
    
    taskSections.forEach(section => {
      if (section.title === "LinkedIn PersonalBrand" || section.title === "LI Pers.Brand") {
        section.tasks.forEach(task => {
          dayTotalLinkedIn += task.count || 1;
        });
      }
    });
    
    return sum + dayTotalLinkedIn;
  }, 0);

  const linkedInProgress = totalLinkedInTasks > 0 ? Math.round((completedLinkedInTasks / totalLinkedInTasks) * 100) : 0;

  // Berechne tägliche Aufgaben
  const completedDailyTasks = weekdays.reduce((sum, day) => {
    const savedProgress = localStorage.getItem(`progress_${day}`);
    if (!savedProgress) return sum;
    
    try {
      const dayProgress = JSON.parse(savedProgress);
      let completedDaily = 0;
      let taskIndex = 0;
      
      const taskSections = dayTasks[day] || [];
      taskSections.forEach((section) => {
        if (section.title === "📋 Tägliche Aufgaben") {
          section.tasks.forEach((task) => {
            const subtaskCount = task.count || 1;
            const taskChecks = dayProgress[taskIndex] || [];
            for (let i = 0; i < subtaskCount; i++) {
              if (taskChecks[i]) {
                completedDaily++;
              }
            }
            taskIndex++;
          });
        } else {
          section.tasks.forEach(() => {
            taskIndex++;
          });
        }
      });
      
      return sum + completedDaily;
    } catch (error) {
      console.error(`Fehler beim Berechnen der täglichen Aufgaben für ${day}:`, error);
      return sum;
    }
  }, 0);

  // Berechne Gesamtanzahl tägliche Aufgaben
  const totalDailyTasks = weekdays.reduce((sum, day) => {
    const taskSections = dayTasks[day] || [];
    let dayTotalDaily = 0;
    
    taskSections.forEach(section => {
      if (section.title === "📋 Tägliche Aufgaben") {
        section.tasks.forEach(task => {
          dayTotalDaily += task.count || 1;
        });
      }
    });
    
    return sum + dayTotalDaily;
  }, 0);

  // Berechne Wochenfortschritt: Tägliche Aufgaben (100%) + Booster-Aufgaben (je 10%)
  const dailyProgress = totalDailyTasks > 0 ? (completedDailyTasks / totalDailyTasks) * 100 : 0;
  const boosterProgress = completedBoosterTasks * 10;
  const totalWeekProgress = Math.round(dailyProgress + boosterProgress);

  return (
    <div className="container" style={{ padding: "var(--spacing-2xl) var(--spacing-lg)", minHeight: "100vh" }}>
      {/* Hero Section */}
      <div className="text-center mb-xl animate-fade-in">
        <div style={{ marginBottom: "var(--spacing-lg)" }}>
          <img 
            src="/vite.svg" 
            alt="Logo" 
            style={{ 
              height: "80px", 
              width: "auto",
              filter: "drop-shadow(0 4px 8px rgba(0, 0, 0, 0.1))"
            }} 
          />
        </div>
        <h1 className="heading-1" style={{ 
          background: "linear-gradient(135deg, #646cff, #747bff)",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
          backgroundClip: "text",
          marginBottom: "var(--spacing-md)"
        }}>
          SuperSales-App
        </h1>
      </div>

      {/* Wochenziele */}
      <div className="card mb-xl animate-slide-in" style={{
        background: "linear-gradient(135deg, var(--primary-navy), var(--primary-navy-light))",
        color: "white",
        border: "none"
      }}>
        <div className="card-body text-center">
          {/* Wechselnde Überschrift für Ziele */}
          <h3 style={{ 
            fontSize: "1.125rem", 
            fontWeight: "600", 
            color: "rgba(255, 255, 255, 0.9)",
            margin: "0 0 var(--spacing-lg) 0",
            textAlign: "center"
          }}>
           Meine Wochenziele - {currentGoalHeadline}
          </h3>
          
          {/* Wochenziele */}
          <div className="grid grid-cols-3 gap-lg">
            {weeklyGoals.map((goal, index) => (
              <div key={index}>
                {editGoalIndex === index || !goal ? (
                  <input
                    type="text"
                    className="form-input"
                    placeholder={`Ziel ${index + 1}`}
                    value={goal}
                    onChange={(e) => handleGoalChange(index, e.target.value)}
                    onBlur={(e) => handleGoalSubmit(index, e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleGoalSubmit(index, goal)}
                    autoFocus
                    style={{
                      background: "rgba(255, 255, 255, 0.95)",
                      border: "1px solid rgba(255, 255, 255, 0.3)",
                      color: "var(--primary-navy)"
                    }}
                  />
                ) : (
                  <div
                    onClick={() => setEditGoalIndex(index)}
                    className="card"
                    style={{
                      background: "rgba(255, 255, 255, 0.15)",
                      backdropFilter: "blur(10px)",
                      border: "1px solid rgba(255, 255, 255, 0.3)",
                      color: "white",
                      cursor: "pointer",
                      textAlign: "center",
                      padding: "var(--spacing-lg)",
                      minHeight: "80px",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      transition: "all 0.3s ease"
                    }}
                    onMouseOver={(e) => {
                      e.currentTarget.style.background = "rgba(255, 255, 255, 0.25)";
                      e.currentTarget.style.transform = "translateY(-2px)";
                    }}
                    onMouseOut={(e) => {
                      e.currentTarget.style.background = "rgba(255, 255, 255, 0.15)";
                      e.currentTarget.style.transform = "translateY(0)";
                    }}
                  >
                    <span style={{ fontWeight: "600" }}>✅ {goal}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Wochenübersicht */}
      <div className="card mb-xl">
        <div className="card-header">
          <h2 className="heading-3" style={{ margin: "0" }}>📅 Vertriebsaufgaben - Wochenübersicht </h2>
        </div>
        <div className="card-body">
          {/* Erste Zeile: Mo-Do */}
          <div className="grid grid-cols-4 gap-lg mb-lg">
            {weekdays.map((day) => {
              if (!["Mo", "Di", "Mi", "Do"].includes(day)) return null;
              
              const taskSections = dayTasks[day] || [];
              let totalTasks = 0;
              taskSections.forEach(section => {
                section.tasks.forEach(task => {
                  if (!task.isBooster) {
                    totalTasks += task.count || 1;
                  }
                });
              });
              
              const dailyTasksComplete = hasDailyTasks(day);
              const progress = getDayProgress(day, totalTasks);
              const hasBooster = hasBoosterTasks(day);
              const hasLinkedIn = hasLinkedInTasks(day);
              
              return (
                <div
                  key={day}
                  onClick={() => navigate(`/tag/${day}`)}
                  className="card"
                  style={{
                    cursor: "pointer",
                    textAlign: "center",
                    padding: "var(--spacing-lg)",
                    background: dailyTasksComplete 
                      ? "linear-gradient(135deg, var(--success-light), var(--success))" 
                      : "var(--background-primary)",
                    border: dailyTasksComplete ? "2px solid var(--success)" : "1px solid var(--border-light)",
                    minHeight: "120px",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "center",
                    alignItems: "center",
                    gap: "var(--spacing-sm)"
                  }}
                >
                  <div style={{ 
                    fontSize: "1.5rem", 
                    fontWeight: "700",
                    color: dailyTasksComplete ? "white" : "var(--text-primary)"
                  }}>
                    {day}
                  </div>
                  <div style={{ fontSize: "1.5rem", display: "flex", gap: "var(--spacing-xs)" }}>
                    {dailyTasksComplete && <span>🏆</span>}
                    {hasLinkedIn && <span>🇱</span>}
                    {hasBooster && <span>🚀</span>}
                  </div>
                  {!dailyTasksComplete && !hasLinkedIn && !hasBooster && (
                    <div style={{ 
                      fontSize: "0.875rem", 
                      color: "var(--text-secondary)",
                      textAlign: "center"
                    }}>
                      {progress}%
                    </div>
                  )}
                </div>
              );
            })}
          </div>
          
          {/* Zweite Zeile: Fr-So + Jahresübersicht */}
          <div className="grid grid-cols-4 gap-lg">
            {weekdays.map((day) => {
              if (!["Fr", "Sa", "So"].includes(day)) return null;
              
              const taskSections = dayTasks[day] || [];
              let totalTasks = 0;
              taskSections.forEach(section => {
                section.tasks.forEach(task => {
                  if (!task.isBooster) {
                    totalTasks += task.count || 1;
                  }
                });
              });
              
              const dailyTasksComplete = hasDailyTasks(day);
              const progress = getDayProgress(day, totalTasks);
              const isWeekend = day === "Sa" || day === "So";
              const hasBooster = hasBoosterTasks(day);
              const hasLinkedIn = hasLinkedInTasks(day);
              
              return (
                <div
                  key={day}
                  onClick={() => navigate(`/tag/${day}`)}
                  className="card"
                  style={{
                    cursor: "pointer",
                    textAlign: "center",
                    padding: "var(--spacing-lg)",
                    background: dailyTasksComplete 
                      ? "linear-gradient(135deg, var(--success-light), var(--success))" 
                      : isWeekend 
                        ? "var(--background-tertiary)"
                        : "var(--background-primary)",
                    border: dailyTasksComplete ? "2px solid var(--success)" : "1px solid var(--border-light)",
                    minHeight: "120px",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "center",
                    alignItems: "center",
                    gap: "var(--spacing-sm)"
                  }}
                >
                  <div style={{ 
                    fontSize: "1.5rem", 
                    fontWeight: "700",
                    color: dailyTasksComplete ? "white" : "var(--text-primary)"
                  }}>
                    {day}
                  </div>
                  <div style={{ fontSize: "1.5rem", display: "flex", gap: "var(--spacing-xs)" }}>
                    {dailyTasksComplete && <span>🏆</span>}
                    {hasLinkedIn && <span>🇱</span>}
                    {hasBooster && <span>🚀</span>}
                  </div>
                  {!dailyTasksComplete && !isWeekend && !hasLinkedIn && !hasBooster && (
                    <div style={{ 
                      fontSize: "0.875rem", 
                      color: "var(--text-secondary)",
                      textAlign: "center"
                    }}>
                      {progress}%
                    </div>
                  )}
                  {isWeekend && !dailyTasksComplete && !hasLinkedIn && !hasBooster && (
                    <div style={{ fontSize: "1rem", color: "var(--text-muted)" }}>
                      Optional
                    </div>
                  )}
                </div>
              );
            })}
            
            {/* Jahresübersicht Button */}
            <button
              onClick={() => navigate("/jahresuebersicht")}
              className="card"
              style={{
                cursor: "pointer",
                textAlign: "center",
                padding: "var(--spacing-lg)",
                background: "linear-gradient(135deg, var(--accent-gold-light), var(--accent-gold))",
                color: "white",
                border: "none",
                minHeight: "120px",
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
                gap: "var(--spacing-sm)"
              }}
            >
              <div style={{ fontSize: "1.5rem", fontWeight: "700" }}>
                📊
              </div>
              <div style={{ fontSize: "0.875rem", fontWeight: "600" }}>
                Jahres-übersicht
              </div>
            </button>
          </div>
          
          <div className="text-center" style={{ marginTop: "var(--spacing-lg)" }}>
            <div className="text-secondary" style={{ fontSize: "0.875rem" }}>
              Klicke auf einen Tag, um deine Aufgaben zu bearbeiten
            </div>
          </div>
        </div>
      </div>

      {/* Success Metrics */}
      <div className="card mb-xl">
        <div className="card-header">
          <h2 className="heading-3" style={{ margin: "0" }}>📊 Erfolgsmetriken</h2>
        </div>
        <div className="card-body">
          <div className="grid grid-cols-3 gap-lg">
            <div className="text-center">
              <div style={{ 
                fontSize: "2rem", 
                fontWeight: "700",
                color: "var(--primary-navy)",
                marginBottom: "var(--spacing-sm)"
              }}>
                {weeklyProgress}%
              </div>
              <div className="text-secondary">Tägliche Aufgaben</div>
            </div>
            <div className="text-center">
              <div style={{ 
                fontSize: "2rem", 
                fontWeight: "700",
                color: "#0a66c2",
                marginBottom: "var(--spacing-sm)"
              }}>
                {linkedInProgress}%
              </div>
              <div className="text-secondary">LI Pers.Brand</div>
            </div>
            <div className="text-center">
              <div style={{ 
                fontSize: "2rem", 
                fontWeight: "700",
                color: "#7c3aed",
                marginBottom: "var(--spacing-sm)"
              }}>
                🐝 {completedBoosterTasks}
              </div>
              <div className="text-secondary">Fleißbienchen</div>
            </div>
          </div>
        </div>
      </div>

      {/* Time Tracking Overview */}
      <div className="card">
        <div className="card-header">
          <div className="flex justify-between items-center">
            <h2 className="heading-3" style={{ margin: "0" }}>⏰ Arbeitszeit-Übersicht</h2>
            <button
              onClick={() => navigate("/zeiterfassung")}
              className="btn btn-primary"
            >
              📝 Zeiten erfassen
            </button>
          </div>
        </div>
        <div className="card-body">
          <div className="grid grid-cols-3 gap-lg">
            <div className="card" style={{ 
              background: "linear-gradient(135deg, #dbeafe, #bfdbfe)",
              border: "1px solid #93c5fd"
            }}>
              <div className="card-body text-center">
                <div style={{ fontSize: "0.875rem", color: "var(--primary-navy)", fontWeight: "600", marginBottom: "var(--spacing-sm)" }}>
                  📅 Diese Woche
                </div>
                <div style={{ fontSize: "2rem", fontWeight: "700", color: "var(--primary-navy-dark)" }}>
                  {formatHours(timeStats.weekHours * 60)}
                </div>
              </div>
            </div>

            <div className="card" style={{ 
              background: "linear-gradient(135deg, #d1fae5, #a7f3d0)",
              border: "1px solid #6ee7b7"
            }}>
              <div className="card-body text-center">
                <div style={{ fontSize: "0.875rem", color: "var(--success)", fontWeight: "600", marginBottom: "var(--spacing-sm)" }}>
                  📊 Dieser Monat
                </div>
                <div style={{ fontSize: "2rem", fontWeight: "700", color: "#047857" }}>
                  {formatHours(timeStats.monthHours * 60)}
                </div>
              </div>
            </div>

            <div className="card" style={{ 
              background: "linear-gradient(135deg, #fef3c7, #fde68a)",
              border: "1px solid #fcd34d"
            }}>
              <div className="card-body text-center">
                <div style={{ fontSize: "0.875rem", color: "var(--accent-gold-dark)", fontWeight: "600", marginBottom: "var(--spacing-sm)" }}>
                  📈 Dieses Jahr
                </div>
                <div style={{ fontSize: "2rem", fontWeight: "700", color: "#92400e" }}>
                  {formatHours(timeStats.yearHours * 60)}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}