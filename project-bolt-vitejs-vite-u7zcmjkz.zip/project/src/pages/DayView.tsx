import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { dayTasks } from "../data/tasks";
import type { TaskItem, TaskSection } from "../data/tasks";

interface ReflectionData {
  success: string;
  learned: string;
  feeling: string;
  improve: string;
  notes: string;
}

interface TaskProgress {
  [taskIndex: number]: boolean[];
}

export default function DayView() {
  const { day } = useParams<{ day: string }>();
  const navigate = useNavigate();
  const [taskProgress, setTaskProgress] = useState<TaskProgress>({});
  const [reflections, setReflections] = useState<ReflectionData>({
    success: "",
    learned: "",
    feeling: "",
    improve: "",
    notes: ""
  });
  const [showReflection, setShowReflection] = useState<boolean>(false);

  const currentDay = day || "Mo";
  const taskSections = dayTasks[currentDay] || [];
  const isWeekend = currentDay === "Sa" || currentDay === "So";

  // Fortschritt aus localStorage laden beim Komponenten-Mount
  useEffect(() => {
    // Task Progress laden
    const savedProgress = localStorage.getItem(`progress_${currentDay}`);
    if (savedProgress) {
      try {
        const parsedProgress = JSON.parse(savedProgress);
        setTaskProgress(parsedProgress);
      } catch (error) {
        console.error(`Fehler beim Laden des Fortschritts für ${currentDay}:`, error);
        setTaskProgress({});
      }
    } else {
      setTaskProgress({});
    }

    // Reflexionen laden
    const savedReflections = localStorage.getItem(`reflection_${currentDay}`);
    if (savedReflections) {
      try {
        const parsedReflections = JSON.parse(savedReflections);
        setReflections(parsedReflections);
      } catch (error) {
        console.error(`Fehler beim Laden der Reflexionen für ${currentDay}:`, error);
      }
    }
  }, [currentDay]);

  // Task Progress in localStorage speichern bei Änderungen
  useEffect(() => {
    if (Object.keys(taskProgress).length > 0) {
      localStorage.setItem(`progress_${currentDay}`, JSON.stringify(taskProgress));
    }
  }, [taskProgress, currentDay]);

  // Reflexionen in localStorage speichern bei Änderungen
  useEffect(() => {
    const hasContent = Object.values(reflections).some(value => value.trim() !== "");
    if (hasContent) {
      localStorage.setItem(`reflection_${currentDay}`, JSON.stringify(reflections));
    }
  }, [reflections, currentDay]);

  const handleTaskCheck = (taskIndex: number, subIndex: number = 0) => {
    setTaskProgress(prev => {
      const taskChecks = prev[taskIndex] || [];
      const newTaskChecks = [...taskChecks];
      newTaskChecks[subIndex] = !newTaskChecks[subIndex];
      
      return {
        ...prev,
        [taskIndex]: newTaskChecks
      };
    });
  };

  const handleReflectionChange = (field: keyof ReflectionData, value: string) => {
    setReflections(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const calculateProgress = (): number => {
    let totalSubtasks = 0;
    let completedSubtasks = 0;
    let completedBoosterTasks = 0;
    let taskIndex = 0;

    taskSections.forEach((section) => {
      // Header-Sections werden nicht gezählt
      if (section.isHeader) return;
      
      section.tasks.forEach((task) => {
        const subtaskCount = task.count || 1;
        
        if (task.isBooster) {
          const taskChecks = taskProgress[taskIndex] || [];
          for (let i = 0; i < subtaskCount; i++) {
            if (taskChecks[i]) {
              completedBoosterTasks++;
            }
          }
        } else {
          totalSubtasks += subtaskCount;
          const taskChecks = taskProgress[taskIndex] || [];
          for (let i = 0; i < subtaskCount; i++) {
            if (taskChecks[i]) {
              completedSubtasks++;
            }
          }
        }
        taskIndex++;
      });
    });

    const baseProgress = totalSubtasks > 0 ? (completedSubtasks / totalSubtasks) * 100 : 0;
    const boosterProgress = completedBoosterTasks * 10; // Jede Booster-Aufgabe gibt 10%
    
    return Math.round(baseProgress + boosterProgress);
  };

  const hasWeekendActivity = (): boolean => {
    if (!isWeekend) return false;
    
    // Prüfe ob mindestens eine Aufgabe erledigt wurde
    const hasCompletedTask = Object.values(taskProgress).some(taskChecks => 
      taskChecks.some(Boolean)
    );
    
    // Prüfe ob eine Reflexion ausgefüllt wurde
    const hasReflection = Object.values(reflections).some(value => value.trim() !== "");
    
    return hasCompletedTask || hasReflection;
  };

  const progress = calculateProgress();
  const showBee = isWeekend ? hasWeekendActivity() : progress === 100;

  return (
    <div className="container" style={{ padding: "var(--spacing-2xl) var(--spacing-lg)", minHeight: "100vh" }}>
      <button onClick={() => navigate("/")} className="btn btn-secondary mb-lg">
        ← Zurück zur Übersicht
      </button>

      <div className="mb-xl">
        <h1 className="heading-1" style={{ marginBottom: "var(--spacing-sm)" }}>
          📅 {currentDay} – {isWeekend ? "Freiwilliger Tag" : "Tagesaufgaben"}
        </h1>
        
        <div style={{ 
          fontSize: "1.125rem",
          color: showBee ? "var(--success)" : progress > 100 ? "var(--accent-gold)" : "var(--text-secondary)",
          fontWeight: "600"
        }}>
          {isWeekend 
            ? (showBee ? "🐝 Fleißbienchen verdient!" : "Freiwillige Aktivitäten")
            : (showBee ? "🐝 Alle Aufgaben erledigt!" : progress > 100 ? `🚀 Übererfüllt: ${progress}%` : `Fortschritt: ${progress}%`)
          }
        </div>
        
        {/* Fortschrittsbalken nur für Werktage */}
        {!isWeekend && (
          <div className="progress-bar" style={{ marginTop: "var(--spacing-md)" }}>
            <div 
              className={`progress-fill ${progress >= 100 ? 'success' : progress > 100 ? 'accent' : ''}`} 
              style={{ 
                width: `${Math.min(progress, 100)}%`,
                background: progress > 100 
                  ? "linear-gradient(90deg, var(--accent-gold), var(--accent-gold-light))" 
                  : progress === 100 
                    ? "linear-gradient(90deg, var(--success), #34d399)"
                    : "linear-gradient(90deg, var(--primary-navy), var(--primary-navy-light))"
              }} 
            />
            {progress > 100 && (
              <div style={{
                position: "absolute",
                right: "8px",
                top: "50%",
                transform: "translateY(-50%)",
                fontSize: "0.75rem",
                fontWeight: "600",
                color: "white"
              }}>
                🚀 {progress}%
              </div>
            )}
          </div>
        )}
      </div>

      {/* Aufgaben */}
      <div className="mb-2xl">
        <div className="flex flex-col gap-xl">
          {taskSections.map((section, sectionIndex) => {
            // Berechne den globalen taskIndex für diese Section
            let taskIndex = 0;
            for (let i = 0; i < sectionIndex; i++) {
              taskIndex += taskSections[i].tasks.length;
            }
            
            return (
              <div key={sectionIndex} className="card" style={{
                border: `2px solid ${section.borderColor}`,
                background: section.backgroundColor
              }}>
                <div className="card-header" style={{
                  background: section.backgroundColor,
                  borderBottom: `1px solid ${section.borderColor}`,
                  padding: "var(--spacing-md) var(--spacing-lg)"
                }}>
                  <h3 style={{
                    margin: "0",
                    fontSize: "1.25rem",
                    fontWeight: "700",
                    color: section.color
                  }}>
                    {section.title}
                  </h3>
                </div>
                
                <div className="card-body" style={{ background: "white" }}>
                  <div className="flex flex-col gap-lg">
                    {section.tasks.map((task, localTaskIndex) => {
                      const currentTaskIndex = taskIndex;
                      const subtaskCount = task.count || 1;
                      const taskChecks = taskProgress[currentTaskIndex] || [];
                      
                      // Increment taskIndex für nächste Aufgabe
                      taskIndex++;
                      
                      return (
                        <div key={localTaskIndex} style={{
                          padding: "var(--spacing-md)",
                          borderRadius: "var(--radius-md)",
                          background: task.isBooster ? "#f3e8ff" : "var(--background-secondary)",
                          border: task.isBooster ? "1px solid #8b5cf6" : "1px solid var(--border-light)"
                        }}>
                          <div className="flex items-start gap-sm">
                            {task.isBooster && (
                              <div style={{
                                fontSize: "1rem",
                                marginTop: "2px"
                              }}>
                                🚀
                              </div>
                            )}
                            <div style={{ flex: 1 }}>
                              <h4 style={{ 
                                fontSize: "1rem", 
                                marginBottom: subtaskCount > 1 ? "var(--spacing-md)" : "var(--spacing-sm)",
                                fontWeight: "600",
                                color: task.isBooster ? "#7c3aed" : "var(--text-primary)"
                              }}>
                                {task.text}
                                {task.isBooster && (
                                  <span style={{
                                    fontSize: "0.75rem",
                                    color: "#7c3aed",
                                    marginLeft: "var(--spacing-sm)",
                                    fontWeight: "500"
                                  }}>
                                    (Bonus für 100%+)
                                  </span>
                                )}
                              </h4>
                              
                              {subtaskCount > 1 ? (
                                <div className="flex flex-col gap-sm">
                                  {Array.from({ length: subtaskCount }, (_, subIndex) => (
                                    <div key={subIndex} className="flex items-center gap-sm">
                                      <label className="flex items-center" style={{ cursor: "pointer", minWidth: "80px" }}>
                                        <input
                                          type="checkbox"
                                          checked={taskChecks[subIndex] || false}
                                          onChange={() => handleTaskCheck(currentTaskIndex, subIndex)}
                                          style={{ marginRight: "var(--spacing-xs)", cursor: "pointer" }}
                                        />
                                        <span>{subIndex + 1}.</span>
                                      </label>
                                      <input
                                        type="text"
                                        placeholder="Ergebnis eintragen..."
                                        className="form-input"
                                        style={{ flex: 1 }}
                                      />
                                    </div>
                                  ))}
                                </div>
                              ) : (
                                <div className="flex flex-col gap-sm">
                                  <label className="flex items-center" style={{ cursor: "pointer" }}>
                                    <input
                                      type="checkbox"
                                      checked={taskChecks[0] || false}
                                      onChange={() => handleTaskCheck(currentTaskIndex, 0)}
                                      style={{ marginRight: "var(--spacing-sm)", cursor: "pointer" }}
                                    />
                                    <span style={{
                                      textDecoration: taskChecks[0] ? "line-through" : "none",
                                      color: taskChecks[0] ? "var(--text-muted)" : "var(--text-primary)"
                                    }}>
                                      Erledigt
                                    </span>
                                  </label>
                                  {isWeekend && (
                                    <textarea
                                      rows={2}
                                      placeholder="Was hast du gemacht? (optional)"
                                      className="form-input"
                                      style={{ resize: "vertical", marginTop: "var(--spacing-sm)" }}
                                    />
                                  )}
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Reflexion */}
      <div className="card">
        <button
          onClick={() => setShowReflection(!showReflection)}
          className="w-full flex justify-between items-center"
          style={{ 
            padding: "var(--spacing-lg)", 
            background: "transparent", 
            border: "none", 
            cursor: "pointer",
            fontSize: "1.25rem",
            fontWeight: "600"
          }}
        >
          <span>📝 Tagesreflexion</span>
          <span style={{
            fontSize: "1rem",
            transform: showReflection ? "rotate(180deg)" : "rotate(0deg)",
            transition: "transform 0.2s ease"
          }}>
            ▼
          </span>
        </button>

        {showReflection && (
          <>
            <div className="card-body" style={{ borderTop: "1px solid var(--border-light)" }}>
            <div className="flex flex-col gap-lg">
          {/* Erfolg */}
          <div>
            <label className="form-label">
              🏆 Was war heute dein größter Erfolg?
            </label>
            <textarea
              rows={2}
              value={reflections.success}
              onChange={(e) => handleReflectionChange('success', e.target.value)}
              className="form-input"
              style={{ resize: "vertical" }}
              placeholder="Beschreibe deinen größten Erfolg heute..."
            />
          </div>

          {/* Lernen */}
          <div>
            <label className="form-label">
              💡 Was hast du gelernt oder erkannt?
            </label>
            <textarea
              rows={2}
              value={reflections.learned}
              onChange={(e) => handleReflectionChange('learned', e.target.value)}
              className="form-input"
              style={{ resize: "vertical" }}
              placeholder="Welche Erkenntnisse hattest du heute?"
            />
          </div>

          {/* Gefühl */}
          <div>
            <label className="form-label">
              😊 Wie geht's dir heute?
            </label>
            <div className="flex flex-col gap-sm">
              {[
                { value: "krank", label: "😷 Krank", color: "var(--error)" },
                { value: "schlecht", label: "😞 Schlecht", color: "#ea580c" },
                { value: "müde", label: "😴 Müde", color: "var(--warning)" },
                { value: "okay", label: "😐 Okay", color: "#65a30d" },
                { value: "gut", label: "😊 Gut", color: "var(--success)" },
                { value: "sehr-gut", label: "😄 Sehr gut", color: "var(--primary-navy-light)" },
                { value: "traumhaft", label: "🤩 Traumhaft", color: "#7c3aed" }
              ].map((mood) => (
                <label 
                  key={mood.value} 
                  className="flex items-center"
                  style={{
                    cursor: "pointer",
                    padding: "var(--spacing-sm)",
                    borderRadius: "var(--radius-md)",
                    border: reflections.feeling === mood.value ? `2px solid ${mood.color}` : "1px solid var(--border-light)",
                    backgroundColor: reflections.feeling === mood.value ? `${mood.color}15` : "transparent",
                    transition: "all 0.2s ease"
                  }}
                >
                  <input
                    type="radio"
                    name="feeling"
                    value={mood.value}
                    checked={reflections.feeling === mood.value}
                    onChange={(e) => handleReflectionChange('feeling', e.target.value)}
                    style={{ marginRight: "var(--spacing-sm)", cursor: "pointer" }}
                  />
                  <span style={{ 
                    color: reflections.feeling === mood.value ? mood.color : "var(--text-primary)",
                    fontWeight: reflections.feeling === mood.value ? "600" : "400"
                  }}>
                    {mood.label}
                  </span>
                </label>
              ))}
            </div>
          </div>

          {/* Verbesserung */}
          <div>
            <label className="form-label">
              🚀 Was möchtest du morgen besser machen?
            </label>
            <textarea
              rows={2}
              value={reflections.improve}
              onChange={(e) => handleReflectionChange('improve', e.target.value)}
              className="form-input"
              style={{ resize: "vertical" }}
              placeholder="Welche Verbesserungen planst du für morgen?"
            />
          </div>

          {/* Persönliche Notizen */}
          <div>
            <label className="form-label">
              📋 Persönliche Notizen (optional)
            </label>
            <textarea
              rows={3}
              value={reflections.notes}
              onChange={(e) => handleReflectionChange('notes', e.target.value)}
              className="form-input"
              style={{ resize: "vertical" }}
              placeholder="Weitere Gedanken, Ideen oder Notizen..."
            />
          </div>
        </div>

            <div style={{ 
          fontSize: "0.875rem", 
          color: "var(--text-muted)", 
          marginTop: "var(--spacing-md)",
          padding: "var(--spacing-sm)",
          background: "var(--background-tertiary)",
          borderRadius: "var(--radius-md)"
        }}>
          💡 <strong>Tipp:</strong> Ehrliche Reflexion hilft dir dabei, kontinuierlich zu wachsen und deine Ziele zu erreichen. Alle Eingaben werden automatisch gespeichert.
        </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}