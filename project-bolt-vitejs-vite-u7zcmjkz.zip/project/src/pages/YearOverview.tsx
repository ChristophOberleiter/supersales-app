import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { dayTasks } from '../data/tasks';

interface TaskProgress {
  [day: string]: boolean[];
}

interface WeekData {
  weekNumber: number;
  startDate: string;
  endDate: string;
  progress: {
    [day: string]: {
      completed: number;
      total: number;
      percentage: number;
    };
  };
  weeklyTotal: {
    completed: number;
    total: number;
    percentage: number;
  };
}

const weekdays = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"];

export default function YearOverview() {
  const navigate = useNavigate();
  const [taskProgress, setTaskProgress] = useState<TaskProgress>({});
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());

  useEffect(() => {
    const savedProgress = localStorage.getItem('vertriebswoche-progress');
    if (savedProgress) {
      try {
        setTaskProgress(JSON.parse(savedProgress));
      } catch (error) {
        console.error('Fehler beim Laden des Fortschritts:', error);
      }
    }
  }, []);

  const getWeekNumber = (date: Date): number => {
    const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
    const dayNum = d.getUTCDay() || 7;
    d.setUTCDate(d.getUTCDate() + 4 - dayNum);
    const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    return Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
  };

  const getWeeksInYear = (year: number): WeekData[] => {
    const weeks: WeekData[] = [];
    const startOfYear = new Date(year, 0, 1);
    const endOfYear = new Date(year, 11, 31);
    
    // Finde den ersten Montag des Jahres
    let currentDate = new Date(startOfYear);
    while (currentDate.getDay() !== 1) {
      currentDate.setDate(currentDate.getDate() + 1);
    }

    while (currentDate <= endOfYear) {
      const weekStart = new Date(currentDate);
      const weekEnd = new Date(currentDate);
      weekEnd.setDate(weekEnd.getDate() + 6);
      
      const weekNumber = getWeekNumber(weekStart);
      
      const weekProgress: { [day: string]: { completed: number; total: number; percentage: number } } = {};
      let weekTotalCompleted = 0;
      let weekTotalTasks = 0;

      weekdays.forEach(day => {
        const dayTasks = taskProgress[day] || [];
        const totalTasks = dayTasks.length || 0;
        const completedTasks = dayTasks.filter(Boolean).length;
        
        weekProgress[day] = {
          completed: completedTasks,
          total: totalTasks,
          percentage: totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0
        };
        
        weekTotalCompleted += completedTasks;
        weekTotalTasks += totalTasks;
      });

      weeks.push({
        weekNumber,
        startDate: weekStart.toLocaleDateString('de-DE'),
        endDate: weekEnd.toLocaleDateString('de-DE'),
        progress: weekProgress,
        weeklyTotal: {
          completed: weekTotalCompleted,
          total: weekTotalTasks,
          percentage: weekTotalTasks > 0 ? Math.round((weekTotalCompleted / weekTotalTasks) * 100) : 0
        }
      });

      currentDate.setDate(currentDate.getDate() + 7);
    }

    return weeks;
  };

  const yearData = getWeeksInYear(selectedYear);
  const currentWeek = getWeekNumber(new Date());

  return (
    <div className="container" style={{ padding: "var(--spacing-2xl) var(--spacing-lg)", minHeight: "100vh" }}>
      <button onClick={() => navigate("/")} className="btn btn-secondary mb-lg">
        ← Zurück zur Übersicht
      </button>

      <div className="mb-xl">
        <h1 className="heading-1" style={{ marginBottom: "var(--spacing-sm)" }}>
          📊 Jahresübersicht {selectedYear}
        </h1>
        
        <div className="flex items-center gap-md mb-lg">
          <label className="form-label" style={{ margin: 0 }}>Jahr auswählen:</label>
          <select
            value={selectedYear}
            onChange={(e) => setSelectedYear(parseInt(e.target.value))}
            className="form-select"
            style={{ width: "120px" }}
          >
            {Array.from({ length: 5 }, (_, i) => {
              const year = new Date().getFullYear() - 2 + i;
              return (
                <option key={year} value={year}>
                  {year}
                </option>
              );
            })}
          </select>
        </div>
      </div>

      {/* Jahresstatistiken */}
      <div className="card mb-xl">
        <div className="card-header">
          <h2 className="heading-3" style={{ margin: "0" }}>📈 Jahresstatistiken</h2>
        </div>
        <div className="card-body">
          <div className="grid grid-cols-3 gap-lg">
            <div className="text-center">
              <div style={{ 
                fontSize: "2.5rem", 
                fontWeight: "700",
                color: "var(--success)",
                marginBottom: "var(--spacing-sm)"
              }}>
                {yearData.filter(week => week.weeklyTotal.percentage === 100).length}
              </div>
              <div className="text-secondary">Perfekte Wochen</div>
            </div>
            <div className="text-center">
              <div style={{ 
                fontSize: "2.5rem", 
                fontWeight: "700",
                color: "var(--primary-navy)",
                marginBottom: "var(--spacing-sm)"
              }}>
                {Math.round(yearData.reduce((sum, week) => sum + week.weeklyTotal.percentage, 0) / yearData.length) || 0}%
              </div>
              <div className="text-secondary">Durchschnittlicher Fortschritt</div>
            </div>
            <div className="text-center">
              <div style={{ 
                fontSize: "2.5rem", 
                fontWeight: "700",
                color: "var(--accent-gold)",
                marginBottom: "var(--spacing-sm)"
              }}>
                {yearData.reduce((sum, week) => sum + week.weeklyTotal.completed, 0)}
              </div>
              <div className="text-secondary">Erledigte Aufgaben</div>
            </div>
          </div>
        </div>
      </div>

      {/* Wochenübersicht */}
      <div className="card">
        <div className="card-header">
          <h2 className="heading-3" style={{ margin: "0" }}>📅 Wochenübersicht</h2>
        </div>
        <div style={{ maxHeight: "600px", overflowY: "auto" }}>
          {yearData.map((week, index) => {
            const isCurrentWeek = week.weekNumber === currentWeek && selectedYear === new Date().getFullYear();
            
            return (
              <div
                key={week.weekNumber}
                style={{
                  padding: "var(--spacing-lg)",
                  borderBottom: index < yearData.length - 1 ? "1px solid var(--border-light)" : "none",
                  background: isCurrentWeek ? "var(--background-tertiary)" : "transparent"
                }}
              >
                <div className="flex justify-between items-center mb-md">
                  <div>
                    <h3 style={{ 
                      fontSize: "1.125rem", 
                      fontWeight: "600", 
                      margin: "0 0 var(--spacing-xs) 0",
                      color: isCurrentWeek ? "var(--primary-navy)" : "var(--text-primary)"
                    }}>
                      KW {week.weekNumber} {isCurrentWeek && "🔥 Aktuelle Woche"}
                    </h3>
                    <div className="text-secondary" style={{ fontSize: "0.875rem" }}>
                      {week.startDate} – {week.endDate}
                    </div>
                  </div>
                  <div className="flex items-center gap-md">
                    <span className={`status-badge ${
                      week.weeklyTotal.percentage === 100 ? 'status-success' : 
                      week.weeklyTotal.percentage >= 70 ? 'status-warning' : 'status-error'
                    }`}>
                      {week.weeklyTotal.percentage}%
                    </span>
                    {week.weeklyTotal.percentage === 100 && (
                      <div style={{ fontSize: "1.5rem" }}>🏆</div>
                    )}
                  </div>
                </div>

                <div className="progress-bar mb-md">
                  <div 
                    className={`progress-fill ${week.weeklyTotal.percentage === 100 ? 'success' : ''}`}
                    style={{ width: `${week.weeklyTotal.percentage}%` }}
                  />
                </div>

                <div className="grid grid-cols-7 gap-sm">
                  {weekdays.map(day => {
                    const dayProgress = week.progress[day];
                    const isWeekend = day === "Sa" || day === "So";
                    
                    return (
                      <div
                        key={day}
                        className="text-center"
                        style={{
                          padding: "var(--spacing-sm)",
                          borderRadius: "var(--radius-md)",
                          background: dayProgress.percentage === 100 
                            ? "var(--success-light)" 
                            : isWeekend 
                              ? "var(--background-tertiary)"
                              : "var(--background-secondary)",
                          border: dayProgress.percentage === 100 ? "1px solid var(--success)" : "1px solid var(--border-light)"
                        }}
                      >
                        <div style={{ 
                          fontSize: "0.75rem", 
                          fontWeight: "600",
                          color: dayProgress.percentage === 100 ? "var(--success)" : "var(--text-secondary)",
                          marginBottom: "var(--spacing-xs)"
                        }}>
                          {day}
                        </div>
                        <div style={{ 
                          fontSize: "0.875rem",
                          color: dayProgress.percentage === 100 ? "var(--success)" : "var(--text-primary)"
                        }}>
                          {dayProgress.percentage === 100 ? "🐝" : `${dayProgress.percentage}%`}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}