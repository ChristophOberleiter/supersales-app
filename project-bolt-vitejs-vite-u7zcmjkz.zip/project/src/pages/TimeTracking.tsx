import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import type { TimeEntry } from '../types/timeTracking';
import { formatDuration, calculateDurationFromTimes, formatTimeRange } from '../utils/timeUtils';

const ACTIVITY_OPTIONS = [
  'Akquise',
  'Angebot erstellen',
  'Kundentermin',
  'Reisezeit',
  'Administration',
  'Weiterbildung',
  'Sonstiges'
];

interface ActivityEntry {
  activity: string;
  startTime: string;
  endTime: string;
}

export default function TimeTracking() {
  const navigate = useNavigate();
  const [entries, setEntries] = useState<TimeEntry[]>([]);
  const [currentView, setCurrentView] = useState<'week' | 'month'>('week');
  const [selectedMonth, setSelectedMonth] = useState(() => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  });
  
  const [formDate, setFormDate] = useState(new Date().toISOString().split('T')[0]);
  const [activityEntries, setActivityEntries] = useState<ActivityEntry[]>([
    { activity: '', startTime: '', endTime: '' }
  ]);

  const [editingEntry, setEditingEntry] = useState<string | null>(null);
  const [editFormData, setEditFormData] = useState({
    activity: '',
    startTime: '',
    endTime: ''
  });

  // Einträge aus localStorage laden
  useEffect(() => {
    const savedEntries = localStorage.getItem('time-entries');
    if (savedEntries) {
      try {
        const parsedEntries = JSON.parse(savedEntries);
        setEntries(parsedEntries);
      } catch (error) {
        console.error('Fehler beim Laden der Zeiteinträge:', error);
      }
    }
  }, []);

  // Einträge in localStorage speichern
  useEffect(() => {
    if (entries.length > 0) {
      localStorage.setItem('time-entries', JSON.stringify(entries));
    }
  }, [entries]);

  const addActivityRow = () => {
    if (activityEntries.length < 10) {
      setActivityEntries(prev => [...prev, { activity: '', startTime: '', endTime: '' }]);
    }
  };

  const removeActivityRow = (index: number) => {
    if (activityEntries.length > 1) {
      setActivityEntries(prev => prev.filter((_, i) => i !== index));
    }
  };

  const updateActivityEntry = (index: number, field: keyof ActivityEntry, value: string) => {
    setActivityEntries(prev => prev.map((entry, i) => 
      i === index ? { ...entry, [field]: value } : entry
    ));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validierung: Nur ausgefüllte Einträge berücksichtigen
    const validEntries = activityEntries.filter(entry => 
      entry.activity && entry.startTime && entry.endTime
    );
    
    if (validEntries.length === 0) {
      alert('Bitte mindestens eine Tätigkeit mit Zeiten ausfüllen!');
      return;
    }

    // Validierung: Alle Zeiten müssen gültig sein
    for (const entry of validEntries) {
      const duration = calculateDurationFromTimes(entry.startTime, entry.endTime);
      if (duration <= 0) {
        alert(`Die Endzeit muss nach der Startzeit liegen bei: ${entry.activity}`);
        return;
      }
    }

    // Erstelle separate TimeEntry für jede Tätigkeit
    const newEntries: TimeEntry[] = validEntries.map(entry => {
      const duration = calculateDurationFromTimes(entry.startTime, entry.endTime);
      return {
        id: `${Date.now()}-${Math.random()}`,
        date: formDate,
        activity: entry.activity,
        startTime: entry.startTime,
        endTime: entry.endTime,
        duration: duration,
        createdAt: new Date().toISOString()
      };
    });
    
    setEntries(prev => [...newEntries, ...prev].sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    ));

    // Formular zurücksetzen
    setFormDate(new Date().toISOString().split('T')[0]);
    setActivityEntries([{ activity: '', startTime: '', endTime: '' }]);
  };

  const handleDelete = (id: string) => {
    if (confirm('Eintrag wirklich löschen?')) {
      setEntries(prev => prev.filter(entry => entry.id !== id));
    }
  };

  const handleEdit = (entry: TimeEntry) => {
    setEditingEntry(entry.id);
    setEditFormData({
      activity: entry.activity,
      startTime: entry.startTime,
      endTime: entry.endTime
    });
  };

  const handleSaveEdit = (id: string) => {
    if (!editFormData.activity || !editFormData.startTime || !editFormData.endTime) {
      alert('Bitte alle Felder ausfüllen!');
      return;
    }

    const duration = calculateDurationFromTimes(editFormData.startTime, editFormData.endTime);
    
    if (duration <= 0) {
      alert('Die Endzeit muss nach der Startzeit liegen!');
      return;
    }

    setEntries(prev => prev.map(entry => 
      entry.id === id 
        ? { ...entry, ...editFormData, duration }
        : entry
    ));

    setEditingEntry(null);
    setEditFormData({ activity: '', startTime: '', endTime: '' });
  };

  const handleCancelEdit = () => {
    setEditingEntry(null);
    setEditFormData({ activity: '', startTime: '', endTime: '' });
  };

  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    return date.toLocaleDateString('de-DE', {
      weekday: 'short',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  const getWeekEntries = (): TimeEntry[] => {
    const now = new Date();
    const weekStart = new Date(now);
    const day = weekStart.getDay();
    const diff = weekStart.getDate() - day + (day === 0 ? -6 : 1); // Montag als Wochenstart
    weekStart.setDate(diff);
    weekStart.setHours(0, 0, 0, 0);

    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekStart.getDate() + 6);
    weekEnd.setHours(23, 59, 59, 999);

    return entries.filter(entry => {
      const entryDate = new Date(entry.date);
      return entryDate >= weekStart && entryDate <= weekEnd;
    }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  };

  const getWeekEntriesGroupedByDay = (): { [date: string]: TimeEntry[] } => {
    const weekEntries = getWeekEntries();
    const grouped: { [date: string]: TimeEntry[] } = {};
    
    weekEntries.forEach(entry => {
      if (!grouped[entry.date]) {
        grouped[entry.date] = [];
      }
      grouped[entry.date].push(entry);
    });
    
    // Sortiere Einträge innerhalb jedes Tages nach Startzeit
    Object.keys(grouped).forEach(date => {
      grouped[date].sort((a, b) => a.startTime.localeCompare(b.startTime));
    });
    
    return grouped;
  };

  const calculateDayTotal = (dayEntries: TimeEntry[]): number => {
    return dayEntries.reduce((sum, entry) => sum + entry.duration, 0);
  };

  const getMonthEntries = (): TimeEntry[] => {
    const [year, month] = selectedMonth.split('-');
    return entries.filter(entry => {
      const entryDate = new Date(entry.date);
      return entryDate.getFullYear() === parseInt(year) && 
             entryDate.getMonth() === parseInt(month) - 1;
    }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  };

  const getMonthEntriesGroupedByDay = (): { [date: string]: TimeEntry[] } => {
    const monthEntries = getMonthEntries();
    const grouped: { [date: string]: TimeEntry[] } = {};
    
    monthEntries.forEach(entry => {
      if (!grouped[entry.date]) {
        grouped[entry.date] = [];
      }
      grouped[entry.date].push(entry);
    });
    
    return grouped;
  };

  const printMonthView = () => {
    window.print();
  };

  const monthEntriesGrouped = currentView === 'month' ? getMonthEntriesGroupedByDay() : {};
  const monthDates = Object.keys(monthEntriesGrouped).sort((a, b) => new Date(b).getTime() - new Date(a).getTime());
  const weekEntriesGrouped = currentView === 'week' ? getWeekEntriesGroupedByDay() : {};
  const weekDates = Object.keys(weekEntriesGrouped).sort((a, b) => new Date(b).getTime() - new Date(a).getTime());

  // Berechne Monatsgesamtstunden
  const monthTotalHours = monthDates.reduce((total, date) => {
    const dayEntries = monthEntriesGrouped[date];
    const dayTotal = calculateDayTotal(dayEntries);
    return total + dayTotal;
  }, 0);
  return (
    <div className="container" style={{ padding: "var(--spacing-2xl) var(--spacing-lg)", minHeight: "100vh" }}>
      <button onClick={() => navigate("/")} className="btn btn-secondary mb-lg">
        ← Zurück zur Übersicht
      </button>

      <h1 className="heading-1 mb-xl">
        ⏰ Zeiterfassung
      </h1>

      {/* Eingabeformular */}
      <div className="card mb-2xl">
        <div className="card-header">
          <h2 className="heading-3" style={{ margin: "0" }}>
            📝 Neuer Zeiteintrag
          </h2>
        </div>
        <div className="card-body">
          <form onSubmit={handleSubmit} className="flex flex-col gap-lg">
            {/* Datum */}
            <div className="form-group">
              <label className="form-label">
                📅 Datum
              </label>
              <input
                type="date"
                value={formDate}
                onChange={(e) => setFormDate(e.target.value)}
                className="form-input"
                style={{ width: "200px" }}
                required
              />
            </div>

            {/* Tätigkeiten und Zeiten */}
            <div className="form-group">
              <label className="form-label">
                🎯 Tätigkeiten und Arbeitszeiten
              </label>
              
              <div className="flex flex-col gap-md">
                {activityEntries.map((entry, index) => (
                  <div key={index} className="card" style={{
                    background: "var(--background-tertiary)",
                    border: "1px solid var(--border-medium)",
                    padding: "var(--spacing-md)"
                  }}>
                    <div className="flex items-center gap-md">
                      {/* Tätigkeit */}
                      <div style={{ flex: "1" }}>
                        <select
                          value={entry.activity}
                          onChange={(e) => {
                            updateActivityEntry(index, 'activity', e.target.value);
                            // Automatisch neue Zeile hinzufügen wenn letzte Zeile ausgefüllt wird
                            if (index === activityEntries.length - 1 && e.target.value && activityEntries.length < 10) {
                              addActivityRow();
                            }
                          }}
                          className="form-select"
                        >
                          <option value="">Tätigkeit auswählen...</option>
                          {ACTIVITY_OPTIONS.map(activity => (
                            <option key={activity} value={activity}>
                              {activity}
                            </option>
                          ))}
                        </select>
                      </div>
                      
                      {/* Startzeit */}
                      <div className="flex items-center gap-sm">
                        <span className="text-secondary" style={{ minWidth: "30px", fontSize: "0.875rem" }}>Von:</span>
                        <input
                          type="time"
                          value={entry.startTime}
                          onChange={(e) => updateActivityEntry(index, 'startTime', e.target.value)}
                          className="form-input"
                          style={{ width: "120px" }}
                        />
                      </div>
                      
                      {/* Endzeit */}
                      <div className="flex items-center gap-sm">
                        <span className="text-secondary" style={{ minWidth: "30px", fontSize: "0.875rem" }}>Bis:</span>
                        <input
                          type="time"
                          value={entry.endTime}
                          onChange={(e) => updateActivityEntry(index, 'endTime', e.target.value)}
                          className="form-input"
                          style={{ width: "120px" }}
                        />
                      </div>
                      
                      {/* Dauer anzeigen */}
                      {entry.startTime && entry.endTime && (
                        <div className="status-badge" style={{ 
                          background: "linear-gradient(135deg, #dbeafe, #bfdbfe)",
                          color: "var(--primary-navy)",
                          border: "1px solid #93c5fd",
                          minWidth: "80px",
                          textAlign: "center"
                        }}>
                          {formatDuration(calculateDurationFromTimes(entry.startTime, entry.endTime))}
                        </div>
                      )}
                      
                      {/* Löschen Button (nur wenn mehr als eine Zeile) */}
                      {activityEntries.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removeActivityRow(index)}
                          className="btn"
                          style={{
                            background: "var(--error-light)",
                            color: "var(--error)",
                            border: "1px solid #fecaca",
                            padding: "var(--spacing-xs)",
                            minWidth: "auto"
                          }}
                        >
                          🗑️
                        </button>
                      )}
                    </div>
                  </div>
                ))}
                
                {/* Gesamtdauer anzeigen */}
                {activityEntries.some(entry => entry.startTime && entry.endTime) && (
                  <div className="card" style={{
                    background: "linear-gradient(135deg, var(--success-light), #d1fae5)",
                    border: "2px solid var(--success)",
                    padding: "var(--spacing-md)",
                    textAlign: "center"
                  }}>
                    <div style={{
                      fontSize: "1.125rem",
                      fontWeight: "700",
                      color: "var(--success)"
                    }}>
                      📊 Gesamtarbeitszeit: {formatDuration(
                        activityEntries
                          .filter(entry => entry.startTime && entry.endTime)
                          .reduce((sum, entry) => sum + calculateDurationFromTimes(entry.startTime, entry.endTime), 0)
                      )}
                    </div>
                  </div>
                )}
                
                {/* Manuell Zeile hinzufügen Button */}
                {activityEntries.length < 10 && (
                  <button
                    type="button"
                    onClick={addActivityRow}
                    className="btn btn-secondary"
                    style={{ alignSelf: "flex-start" }}
                  >
                    ➕ Weitere Tätigkeit hinzufügen
                  </button>
                )}
              </div>
            </div>

            <button
              type="submit"
              className="btn btn-primary"
              style={{ alignSelf: "flex-start" }}
            >
              💾 Tageseinträge speichern
            </button>
          </form>
        </div>
      </div>

      {/* Ansicht-Umschalter */}
      <div className="flex gap-md mb-xl items-center">
        <button
          onClick={() => setCurrentView('week')}
          className={`btn ${currentView === 'week' ? 'btn-primary' : 'btn-secondary'}`}
        >
          📅 Wochenansicht
        </button>
        <button
          onClick={() => setCurrentView('month')}
          className={`btn ${currentView === 'month' ? 'btn-primary' : 'btn-secondary'}`}
        >
          📊 Monatsansicht
        </button>
        
        {currentView === 'month' && (
          <>
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="form-select"
            >
              {Array.from({ length: 12 }, (_, i) => {
                const date = new Date();
                date.setMonth(date.getMonth() - i);
                const value = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
                const label = date.toLocaleDateString('de-DE', { year: 'numeric', month: 'long' });
                return (
                  <option key={value} value={value}>
                    {label}
                  </option>
                );
              })}
            </select>
            <button
              onClick={printMonthView}
              className="btn btn-success"
            >
              🖨️ Drucken
            </button>
          </>
        )}
      </div>

      {/* Einträge Liste */}
      <div className="card">
        <div className="card-header">
          <h2 className="heading-3" style={{ margin: "0" }}>
            {currentView === 'week' ? '📅 Diese Woche' : `📊 ${selectedMonth.split('-')[1]}/${selectedMonth.split('-')[0]}`} 
            {currentView === 'week' ? ` (${getWeekEntries().length} Einträge)` : ` (${monthDates.length} Arbeitstage)`}
          </h2>
          {currentView === 'month' && monthDates.length > 0 && (
            <div style={{
              marginTop: "var(--spacing-sm)",
              fontSize: "1rem",
              fontWeight: "600",
              color: "var(--success)"
            }}>
              Gesamtstunden: {formatDuration(monthTotalHours)}
            </div>
          )}
        </div>

        {(currentView === 'week' ? weekDates.length === 0 : monthDates.length === 0) ? (
          <div className="card-body text-center" style={{
            padding: "var(--spacing-2xl)",
            color: "var(--text-muted)"
          }}>
            {currentView === 'week' 
              ? "Noch keine Zeiteinträge diese Woche. Erstelle deinen ersten Eintrag!"
              : "Keine Zeiteinträge in diesem Monat gefunden."
            }
          </div>
        ) : (
          <div className="print-area" style={{ maxHeight: currentView === 'month' ? "none" : "600px", overflowY: currentView === 'month' ? "visible" : "auto" }}>
            {currentView === 'week' ? (
              // Wochenansicht: Kompakte Tages-Karten
              <div className="grid grid-cols-1 gap-lg">
                {weekDates.map((date) => {
                  const dayEntries = weekEntriesGrouped[date];
                  const dayTotal = calculateDayTotal(dayEntries);
                  
                  return (
                    <div key={date} className="card" style={{
                      border: "2px solid var(--primary-navy-light)",
                      background: "var(--background-primary)"
                    }}>
                      {/* Tages-Header */}
                      <div style={{
                        padding: "var(--spacing-md) var(--spacing-lg)",
                        background: "linear-gradient(135deg, var(--primary-navy), var(--primary-navy-light))",
                        color: "white",
                        borderRadius: "var(--radius-lg) var(--radius-lg) 0 0"
                      }}>
                        <div className="flex justify-between items-center">
                          <h4 style={{
                            margin: "0",
                            fontSize: "1.125rem",
                            fontWeight: "600"
                          }}>
                            📅 {formatDate(date)}
                          </h4>
                          <div style={{
                            background: "rgba(255, 255, 255, 0.2)",
                            padding: "var(--spacing-xs) var(--spacing-sm)",
                            borderRadius: "var(--radius-sm)",
                            fontSize: "0.875rem",
                            fontWeight: "600"
                          }}>
                            Gesamt: {formatDuration(dayTotal)}
                          </div>
                        </div>
                      </div>
                      
                      {/* Tages-Einträge */}
                      <div style={{ padding: "var(--spacing-lg)" }}>
                        <div className="flex flex-col gap-md">
                          {dayEntries.map((entry) => (
                            <div key={entry.id} style={{
                              padding: "var(--spacing-md)",
                              background: "var(--background-secondary)",
                              borderRadius: "var(--radius-md)",
                              border: "1px solid var(--border-light)"
                            }}>
                              {editingEntry === entry.id ? (
                                // Bearbeitungsmodus
                                <div className="flex flex-col gap-sm">
                                  <select
                                    value={editFormData.activity}
                                    onChange={(e) => setEditFormData(prev => ({ ...prev, activity: e.target.value }))}
                                    className="form-select"
                                  >
                                    <option value="">Tätigkeit auswählen...</option>
                                    {ACTIVITY_OPTIONS.map(activity => (
                                      <option key={activity} value={activity}>
                                        {activity}
                                      </option>
                                    ))}
                                  </select>
                                  <div className="flex gap-sm items-center">
                                    <input
                                      type="time"
                                      value={editFormData.startTime}
                                      onChange={(e) => setEditFormData(prev => ({ ...prev, startTime: e.target.value }))}
                                      className="form-input"
                                      style={{ width: "120px" }}
                                    />
                                    <span>–</span>
                                    <input
                                      type="time"
                                      value={editFormData.endTime}
                                      onChange={(e) => setEditFormData(prev => ({ ...prev, endTime: e.target.value }))}
                                      className="form-input"
                                      style={{ width: "120px" }}
                                    />
                                    <button
                                      onClick={() => handleSaveEdit(entry.id)}
                                      className="btn btn-success"
                                      style={{ fontSize: "0.875rem", padding: "var(--spacing-xs) var(--spacing-sm)" }}
                                    >
                                      💾 Speichern
                                    </button>
                                    <button
                                      onClick={handleCancelEdit}
                                      className="btn btn-secondary"
                                      style={{ fontSize: "0.875rem", padding: "var(--spacing-xs) var(--spacing-sm)" }}
                                    >
                                      ❌ Abbrechen
                                    </button>
                                  </div>
                                </div>
                              ) : (
                                // Anzeigemodus
                                <div className="flex justify-between items-center" style={{ width: "100%" }}>
                                  <div style={{ 
                                    flex: 1,
                                    display: "flex",
                                    alignItems: "center",
                                    gap: "var(--spacing-md)"
                                  }}>
                                    <div style={{
                                      fontSize: "1rem",
                                      fontWeight: "600",
                                      color: "var(--text-primary)",
                                      minWidth: "120px"
                                    }}>
                                      {entry.activity}
                                    </div>
                                    <div style={{
                                      fontSize: "1rem",
                                      fontWeight: "600",
                                      color: "var(--success)",
                                      minWidth: "80px"
                                    }}>
                                      {formatDuration(entry.duration)}
                                    </div>
                                    <div style={{
                                      fontSize: "0.875rem",
                                      color: "var(--text-secondary)",
                                      minWidth: "120px"
                                    }}>
                                      {formatTimeRange(entry.startTime, entry.endTime)}
                                    </div>
                                  </div>
                                  <div className="flex gap-sm">
                                    <button
                                      onClick={() => handleEdit(entry)}
                                      className="btn"
                                      style={{
                                        background: "var(--warning-light)",
                                        color: "var(--warning)",
                                        border: "1px solid #fde68a",
                                        padding: "var(--spacing-xs) var(--spacing-sm)",
                                        fontSize: "0.875rem"
                                      }}
                                    >
                                      ✏️ Bearbeiten
                                    </button>
                                    <button
                                      onClick={() => handleDelete(entry.id)}
                                      className="btn"
                                      style={{
                                        background: "var(--error-light)",
                                        color: "var(--error)",
                                        border: "1px solid #fecaca",
                                        padding: "var(--spacing-xs) var(--spacing-sm)",
                                        fontSize: "0.875rem"
                                      }}
                                    >
                                      🗑️ Löschen
                                    </button>
                                  </div>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              // Monatsansicht: Wie bisher
              <div style={{ 
                background: "white",
                padding: "var(--spacing-lg)",
                borderRadius: "var(--radius-md)"
              }}>
                {/* Monats-Header für Druck */}
                <div style={{
                  textAlign: "center",
                  marginBottom: "var(--spacing-xl)",
                  borderBottom: "2px solid var(--border-medium)",
                  paddingBottom: "var(--spacing-lg)"
                }}>
                  <h2 style={{
                    fontSize: "1.5rem",
                    fontWeight: "700",
                    color: "var(--text-primary)",
                    margin: "0 0 var(--spacing-sm) 0"
                  }}>
                    Arbeitszeit-Übersicht {new Date(selectedMonth + '-01').toLocaleDateString('de-DE', { year: 'numeric', month: 'long' })}
                  </h2>
                  <div style={{
                    fontSize: "1.125rem",
                    fontWeight: "600",
                    color: "var(--success)"
                  }}>
                    Gesamtstunden: {formatDuration(monthTotalHours)}
                  </div>
                </div>

                {/* Tages-Liste */}
                {monthDates.map((date, index) => {
                  const dayEntries = monthEntriesGrouped[date];
                  const dayTotal = calculateDayTotal(dayEntries);
                  
                  return (
                    <div
                      key={date}
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        padding: "var(--spacing-md) 0",
                        borderBottom: index < monthDates.length - 1 ? "1px solid var(--border-light)" : "none",
                        fontSize: "1rem"
                      }}
                    >
                      <div style={{
                        fontWeight: "600",
                        color: "var(--text-primary)"
                      }}>
                        {formatDate(date)}
                      </div>
                      <div style={{
                        fontWeight: "700",
                        color: "var(--success)",
                        fontSize: "1.125rem"
                      }}>
                        {formatDuration(dayTotal)}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>

      <style>{`
        @media print {
          .container > *:not(.print-area) {
            visibility: hidden;
          }
          .print-area, .print-area * {
            visibility: visible;
          }
          .container {
            padding: 20px !important;
          }
          .card {
            box-shadow: none !important;
            border: 1px solid #000 !important;
          }
          .card-header {
            background: white !important;
            border-bottom: 2px solid #000 !important;
          }
          @page {
            margin: 2cm;
            size: A4;
          }
        }
      `}</style>
    </div>
  );
}