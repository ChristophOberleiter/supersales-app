export interface TimeEntry {
  id: string;
  date: string; // YYYY-MM-DD Format
  activity: string;
  startTime: string; // HH:MM Format
  endTime: string; // HH:MM Format
  duration: number; // in Minuten
  createdAt: string; // ISO String
}

export interface TimeStats {
  weekHours: number;
  monthHours: number;
  yearHours: number;
}