import type { TimeEntry, TimeStats } from '../types/timeTracking';

export const formatDuration = (minutes: number): string => {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  
  if (hours === 0) {
    return `${mins}min`;
  } else if (mins === 0) {
    return `${hours}h`;
  } else {
    return `${hours}h ${mins}min`;
  }
};

export const formatHours = (minutes: number): string => {
  const hours = (minutes / 60).toFixed(1);
  return `${hours}h`;
};

export const calculateDurationFromTimes = (startTime: string, endTime: string): number => {
  if (!startTime || !endTime) return 0;
  
  const [startHours, startMinutes] = startTime.split(':').map(Number);
  const [endHours, endMinutes] = endTime.split(':').map(Number);
  
  const startTotalMinutes = startHours * 60 + startMinutes;
  let endTotalMinutes = endHours * 60 + endMinutes;
  
  // Handle overnight work (end time is next day)
  if (endTotalMinutes < startTotalMinutes) {
    endTotalMinutes += 24 * 60; // Add 24 hours
  }
  
  return endTotalMinutes - startTotalMinutes;
};

export const formatTimeRange = (startTime: string, endTime: string): string => {
  return `${startTime}–${endTime}`;
};

export const getWeekStart = (date: Date): Date => {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1); // Montag als Wochenstart
  return new Date(d.setDate(diff));
};

export const getWeekEnd = (date: Date): Date => {
  const weekStart = getWeekStart(date);
  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekStart.getDate() + 6);
  return weekEnd;
};

export const calculateTimeStats = (entries: TimeEntry[]): TimeStats => {
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth();
  const weekStart = getWeekStart(now);
  const weekEnd = getWeekEnd(now);

  let weekMinutes = 0;
  let monthMinutes = 0;
  let yearMinutes = 0;

  entries.forEach(entry => {
    const entryDate = new Date(entry.date);
    
    // Jahresarbeitszeit
    if (entryDate.getFullYear() === currentYear) {
      yearMinutes += entry.duration;
    }
    
    // Monatsarbeitszeit
    if (entryDate.getFullYear() === currentYear && entryDate.getMonth() === currentMonth) {
      monthMinutes += entry.duration;
    }
    
    // Wochenarbeitszeit
    if (entryDate >= weekStart && entryDate <= weekEnd) {
      weekMinutes += entry.duration;
    }
  });

  return {
    weekHours: weekMinutes / 60,
    monthHours: monthMinutes / 60,
    yearHours: yearMinutes / 60
  };
};